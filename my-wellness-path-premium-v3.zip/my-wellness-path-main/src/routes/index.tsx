import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Check, HeartPulse, ShieldCheck, Sparkles } from "lucide-react";
import { AppShell } from "../components/AppShell";

export const Route = createFileRoute("/")({ component: Index });

function Index() {
  return (
    <AppShell wide>
      <section className="grid items-center gap-12 lg:grid-cols-[1.02fr_.98fr] lg:gap-16">
        <div>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <span className="premium-pill"><Sparkles size={14} /> Personalized for women 40+</span>
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .08 }} className="mt-6 max-w-2xl font-display text-5xl leading-[.98] text-foreground sm:text-6xl lg:text-7xl">
            Feel lighter, stronger and more like <em className="not-italic text-primary">yourself.</em>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .16 }} className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
            Take a 3-minute assessment and receive a gentle walking plan shaped around your body, routine and goals — without punishing workouts or impossible rules.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .24 }} className="mt-8">
            <Link to="/assessment" className="premium-cta">Build my free plan <ArrowRight size={18} /></Link>
            <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground"><ShieldCheck size={15} /> Private, free and takes about 3 minutes</p>
          </motion.div>
          <div className="mt-10 grid gap-3 sm:grid-cols-3">
            {["Low-impact walking", "Simple habit system", "Realistic weekly pace"].map((item) => (
              <div key={item} className="flex items-center gap-2 rounded-2xl border border-border/80 bg-white/70 px-4 py-3 text-sm font-medium"><span className="grid h-6 w-6 place-items-center rounded-full bg-primary/10 text-primary"><Check size={14} /></span>{item}</div>
            ))}
          </div>
        </div>
        <motion.div initial={{ opacity: 0, scale: .97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: .7 }} className="relative">
          <div className="absolute -inset-8 -z-10 rounded-full bg-primary/10 blur-3xl" />
          <img src="/wellness-hero.svg" alt="Woman enjoying a gentle wellness walk" className="w-full drop-shadow-[0_30px_50px_rgba(36,76,61,.14)]" />
          <div className="absolute bottom-6 left-4 rounded-2xl border border-white/60 bg-white/90 p-4 shadow-xl backdrop-blur sm:left-8">
            <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-white"><HeartPulse size={20} /></span><div><div className="text-xs text-muted-foreground">Wellness approach</div><div className="font-semibold">Gentle. Personal. Sustainable.</div></div></div>
          </div>
        </motion.div>
      </section>

      <section className="mt-20 grid gap-5 sm:grid-cols-3">
        {[{n:"01",t:"Tell us about you",d:"Your schedule, energy, movement and goals."},{n:"02",t:"See your wellness profile",d:"Understand what may be slowing your progress."},{n:"03",t:"Follow your gentle plan",d:"Small actions that fit into real life."}].map((x)=><div key={x.n} className="premium-card"><span className="text-sm font-semibold text-primary">{x.n}</span><h3 className="mt-5 font-display text-2xl">{x.t}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{x.d}</p></div>)}
      </section>
    </AppShell>
  );
}
