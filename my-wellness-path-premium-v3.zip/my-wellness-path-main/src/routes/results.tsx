import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useMemo } from "react";
import { ArrowRight, Footprints, HeartPulse, Moon, Sparkles } from "lucide-react";
import { AppShell } from "../components/AppShell";
import { useAssessment } from "../context/AssessmentContext";
import { personalize } from "../lib/personalization";
import { ProfileCard } from "../components/results/ProfileCard";
import { PlanPreview } from "../components/results/PlanPreview";
import { HabitStack } from "../components/results/HabitStack";
import { TimelineChart } from "../components/results/TimelineChart";
export const Route = createFileRoute("/results")({ component: Results });

function Results(){const navigate=useNavigate();const{answers}=useAssessment();useEffect(()=>{if(!answers.currentWeightLb||!answers.goalWeightLb)navigate({to:"/"})},[answers,navigate]);const p=useMemo(()=>personalize(answers),[answers]);const score=74;return <AppShell>
  <div className="space-y-6">
    <motion.div initial={{opacity:0,y:10}} animate={{opacity:1,y:0}}><span className="premium-pill"><Sparkles size={14}/> Your personalized wellness read</span><h1 className="mt-5 font-display text-5xl leading-none">You do not need more pressure. You need the right rhythm.</h1><p className="mt-4 text-base leading-relaxed text-muted-foreground">Your answers suggest that a low-impact, consistency-first plan is more likely to work than another intense reset.</p></motion.div>
    <motion.section initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:.08}} className="overflow-hidden rounded-[2rem] border border-border bg-card shadow-[0_30px_80px_-45px_rgba(35,75,59,.45)]">
      <div className="grid gap-6 p-6 sm:grid-cols-[180px_1fr] sm:p-8"><div className="relative mx-auto grid h-40 w-40 place-items-center rounded-full bg-primary/5"><svg className="absolute inset-0 -rotate-90" viewBox="0 0 160 160"><circle cx="80" cy="80" r="68" fill="none" stroke="currentColor" strokeWidth="10" className="text-muted"/><circle cx="80" cy="80" r="68" fill="none" stroke="currentColor" strokeWidth="10" strokeLinecap="round" strokeDasharray="427" strokeDashoffset={427-(427*score/100)} className="text-primary"/></svg><div><div className="font-display text-5xl text-primary">{score}</div><div className="text-[10px] uppercase tracking-widest text-muted-foreground">wellness score</div></div></div><div className="flex flex-col justify-center"><div className="text-xs font-semibold uppercase tracking-wider text-primary">Your profile</div><h2 className="mt-2 font-display text-3xl">The Gentle Momentum Type</h2><p className="mt-3 text-sm leading-relaxed text-muted-foreground">You can make meaningful progress, but your plan must protect your energy and remove all-or-nothing thinking.</p><div className="mt-5 grid grid-cols-3 gap-2">{[{i:Footprints,t:"Movement"},{i:HeartPulse,t:"Energy"},{i:Moon,t:"Recovery"}].map(({i:I,t})=><div key={t} className="rounded-xl bg-muted p-3 text-center"><I size={17} className="mx-auto text-primary"/><div className="mt-1 text-[11px] font-medium">{t}</div></div>)}</div></div></div>
    </motion.section>
    <ProfileCard p={p}/><PlanPreview p={p}/><HabitStack p={p}/><TimelineChart p={p}/>
    <div className="sticky bottom-4 z-20 rounded-2xl border border-primary/15 bg-card/95 p-3 shadow-2xl backdrop-blur"><Link to="/plan" className="premium-cta w-full">See my complete plan <ArrowRight size={18}/></Link></div>
  </div>
</AppShell>}
