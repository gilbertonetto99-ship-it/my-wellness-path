import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Check, LoaderCircle, Sparkles } from "lucide-react";
import { AppShell } from "../components/AppShell";

const STEPS = ["Reviewing your lifestyle", "Matching your ideal walking pace", "Building your habit stack", "Preparing your personalized roadmap"];
export const Route = createFileRoute("/analyzing")({ component: Analyzing });

function Analyzing() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  useEffect(() => { const interval=setInterval(()=>setStep(s=>Math.min(STEPS.length,s+1)),850); const done=setTimeout(()=>navigate({to:"/results"}),3900); return()=>{clearInterval(interval);clearTimeout(done)};},[navigate]);
  const pct=Math.min(100,Math.round((step/STEPS.length)*100));
  return <AppShell><div className="flex min-h-[72vh] flex-col items-center justify-center text-center">
    <motion.div initial={{opacity:0,scale:.9}} animate={{opacity:1,scale:1}} className="relative grid h-32 w-32 place-items-center rounded-full bg-card shadow-[0_24px_70px_-30px_rgba(35,75,59,.4)]">
      <svg className="absolute inset-0 -rotate-90" viewBox="0 0 128 128"><circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="5" fill="none" className="text-muted"/><motion.circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="5" fill="none" strokeLinecap="round" className="text-primary" strokeDasharray={364} animate={{strokeDashoffset:364-(364*pct/100)}} /></svg>
      <div><div className="font-display text-3xl text-primary">{pct}%</div><div className="text-[10px] uppercase tracking-wider text-muted-foreground">complete</div></div>
    </motion.div>
    <span className="premium-pill mt-8"><Sparkles size={14}/> Personalizing your experience</span>
    <h1 className="mt-5 font-display text-4xl">Your plan is taking shape.</h1><p className="mt-3 max-w-md text-muted-foreground">We are turning your answers into a gentle plan designed around your real life.</p>
    <div className="mt-9 w-full max-w-md space-y-3 text-left">{STEPS.map((s,i)=>{const done=i<step;const active=i===step;return <motion.div key={s} animate={{opacity:i<=step?1:.42}} className="flex items-center gap-3 rounded-2xl border border-border bg-card/90 p-4"><span className={`grid h-8 w-8 place-items-center rounded-full ${done?"bg-primary text-white":active?"bg-primary/10 text-primary":"bg-muted text-muted-foreground"}`}>{done?<Check size={16}/>:active?<LoaderCircle size={16} className="animate-spin"/>:<span className="text-xs">{i+1}</span>}</span><span className="text-sm font-medium">{s}</span></motion.div>})}</div>
  </div></AppShell>;
}
