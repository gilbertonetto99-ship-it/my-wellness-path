import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, LockKeyhole, ShieldCheck, Sparkles } from "lucide-react";
import { AppShell } from "../components/AppShell";
import { PROGRAM } from "../config/checkout";
export const Route=createFileRoute("/offer")({component:OfferPage});
const items=["Personalized 12-week walking roadmap","24 guided walking audios","Printable weekly habit tracker","Simple recipes for busy days","Mindset lessons and weekly resets","Lifetime access to every module"];
function OfferPage(){return <AppShell wide><div className="mx-auto max-w-5xl">
  <section className="grid items-center gap-10 lg:grid-cols-[1.05fr_.95fr]">
    <div><span className="premium-pill"><Sparkles size={14}/> Your plan is ready to unlock</span><h1 className="mt-6 font-display text-5xl leading-[1] sm:text-6xl">Turn your personalized result into a simple 12-week routine.</h1><p className="mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground">StrideWell gives you the exact walking rhythm, support tools and weekly structure to stop restarting and finally build gentle momentum.</p>
      <ul className="mt-7 grid gap-3 sm:grid-cols-2">{items.map(x=><li key={x} className="flex gap-2 text-sm"><span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-primary text-white"><Check size={12}/></span>{x}</li>)}</ul>
    </div>
    <div className="rounded-[2rem] border border-primary/15 bg-card p-6 shadow-[0_30px_90px_-45px_rgba(35,75,59,.55)] sm:p-8"><div className="flex items-center justify-between"><span className="text-sm font-semibold text-primary">StrideWell Complete</span><LockKeyhole size={18} className="text-primary"/></div><div className="mt-7 text-sm text-muted-foreground">One-time payment</div><div className="mt-1 flex items-end gap-2"><span className="font-display text-6xl text-foreground">${PROGRAM.price}</span><span className="pb-2 text-sm text-muted-foreground">USD</span></div><p className="mt-3 text-sm text-muted-foreground">No subscription. No auto-renewal.</p><Link to="/checkout" className="premium-cta mt-7 w-full">Unlock my program <ArrowRight size={18}/></Link><div className="mt-5 flex items-center justify-center gap-2 text-xs text-muted-foreground"><ShieldCheck size={15}/> 14-day money-back guarantee</div></div>
  </section>
  <section className="mt-16 grid gap-5 sm:grid-cols-3">{[{t:"Built around you",d:"Your answers shape the pace, habits and progression."},{t:"Made for real life",d:"Short sessions and flexible weekly goals."},{t:"Designed for consistency",d:"A calm system that keeps you moving after motivation fades."}].map(x=><div key={x.t} className="premium-card"><h3 className="font-display text-2xl">{x.t}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{x.d}</p></div>)}</section>
</div></AppShell>}
